
## rubikpatternsLIST.sh
## rubik bundle v5.0, 2018
## run twice to get hyperref-links correct

 pdflatex  --shell-escape  rubikpatternsLIST.tex
 pdflatex  --shell-escape  rubikpatternsLIST.tex

## echo "...checking error file" 
## grep ERROR  ./rubikstateERRORS.dat
